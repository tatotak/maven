package com.tatotak.loop.lifecycle

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tatotak.loop.CoroutineLoop
import com.tatotak.loop.First

@Deprecated(
    "Use [ViewModel.loop] or [CoroutineLoop.Factory.injectInto] instead - this can lead to issues"
)
abstract class LoopViewModel<State, Event, Effect>(
    loopProvider: ViewModel.() -> CoroutineLoop<State, Event, Effect>
) : ViewModel() {
  protected val loop = loopProvider(this)

  fun <State, Event, Effect> ViewModel.loop(
      factory: CoroutineLoop.Factory<State, Event, Effect>,
      first: First<State, Effect>,
  ): CoroutineLoop<State, Event, Effect> = factory.create(viewModelScope, first)

  fun <State, Event, Effect> CoroutineLoop.Factory<State, Event, Effect>.injectInto(
      viewModel: ViewModel,
      first: First<State, Effect>,
  ): CoroutineLoop<State, Event, Effect> = create(viewModel.viewModelScope, first)
}
