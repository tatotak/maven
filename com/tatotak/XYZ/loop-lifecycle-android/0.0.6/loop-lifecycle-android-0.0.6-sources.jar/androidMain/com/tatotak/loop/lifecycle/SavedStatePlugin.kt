package com.tatotak.loop.lifecycle

import android.os.Parcelable
import androidx.lifecycle.SavedStateHandle
import com.tatotak.loop.Next
import com.tatotak.loop.plugin.LoopPlugin

/**
 * Persists a [Parcelable] projection of the loop's state into a [SavedStateHandle] on every
 * reduction that produces a new state.
 *
 * The loop's `State` does not need to be `Parcelable`; only the value returned by [mapper] does.
 * This lets you keep transient, non-parcelable fields (in-flight loads, derived caches, view models
 * of external data) in `State` while persisting only what's needed to rehydrate on process death.
 */
inline fun <State, Event, Effect, reified SavedState : Parcelable> SavedStateHandle.loopPlugin(
  key: String = "loop:${SavedState::class.qualifiedName}",
  noinline mapper: (State) -> SavedState,
): SavedStatePlugin<State, Event, Effect, SavedState> = SavedStatePlugin(this, key, mapper)

/** Convenience overload for when the loop state is itself [Parcelable] and saved as-is. */
inline fun <reified State : Parcelable, Event, Effect> SavedStateHandle.loopPlugin(
  key: String = "loop:${State::class.qualifiedName}"
): SavedStatePlugin<State, Event, Effect, State> = SavedStatePlugin(this, key) { it }

class SavedStatePlugin<State, Event, Effect, SavedState : Parcelable>(
  private val handle: SavedStateHandle,
  private val key: String,
  private val mapper: (State) -> SavedState,
) : LoopPlugin<State, Event, Effect> {

  override fun onReduce(oldState: State, event: Event, next: Next<State, Effect>) {
    next.state?.let { newState -> handle[key] = mapper(newState) }
  }
}
