package com.tatotak.analytics

import com.tatotak.analytics.api.AnalyticsPath

class AnalyticTestRecorder(
    val sink: TestSink = TestSink(),
    val clock: TestElapsedTime = TestElapsedTime(),
) {
  fun analytics(
      path: AnalyticsPath = AnalyticsPath.of("receive", "summary"),
      flowId: String? = "flow-1",
  ) = Analytics(path, flowId, sink, clock)

  val events: List<Pair<String, Map<String, Any>>>
    get() = sink.events

  val names: List<String>
    get() = events.map { it.first }

  val single: Map<String, Any>
    get() = events.single().second

  val last: Map<String, Any>
    get() = events.last().second

  operator fun get(index: Int): Map<String, Any> = events[index].second

  fun bundlesFor(id: String): List<Map<String, Any>> =
      events.filter { it.first == id }.map { it.second }

  fun clear() = sink.clear()
}
