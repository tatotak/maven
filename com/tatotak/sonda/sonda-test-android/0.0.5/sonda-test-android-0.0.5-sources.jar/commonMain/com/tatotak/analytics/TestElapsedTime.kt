package com.tatotak.analytics

class TestElapsedTime(private var value: Long = 0L) : ElapsedTime {
  override fun now(): Long = value

  fun advance(millis: Long) {
    value += millis
  }
}