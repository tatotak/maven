package com.tatotak.analytics

class TestSink : AnalyticsSink {
  val events = mutableListOf<Pair<String, Map<String, Any>>>()
  val userProperties = mutableListOf<Pair<String, String>>()
  val breadcrumbs = mutableListOf<String>()

  val stateWrites = mutableListOf<Pair<String, String>>()

  val currentState = linkedMapOf<String, String>()

  override fun event(id: String, params: Map<String, Any>) {
    events.add(id to params)
  }

  override fun userProperty(id: String, value: String) {
    userProperties += id to value
  }

  override fun breadcrumb(message: String) {
    breadcrumbs += message
  }

  override fun state(key: String, value: String) {
    stateWrites += key to value
    currentState[key] = value
  }

  fun clear() {
    events.clear()
    userProperties.clear()
    breadcrumbs.clear()
    stateWrites.clear()
    currentState.clear()
  }
}

fun Map<String, Any>.getString(key: String) = get(key) as? String
