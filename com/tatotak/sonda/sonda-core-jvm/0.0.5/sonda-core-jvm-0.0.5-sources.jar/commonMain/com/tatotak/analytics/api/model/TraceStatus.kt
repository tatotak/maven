package com.tatotak.analytics.api.model

/** Terminal and non-terminal outcomes of a `process` event. */
enum class TraceStatus(val value: String) {
  Started("started"),
  Succeeded("succeeded"),
  Failed("failed"),
  Cancelled("cancelled"),
}
