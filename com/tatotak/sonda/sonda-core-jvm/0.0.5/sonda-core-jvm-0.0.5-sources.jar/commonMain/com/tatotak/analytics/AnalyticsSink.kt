package com.tatotak.analytics

interface AnalyticsSink {
  fun event(id: String, params: Map<String, Any>)

  fun userProperty(id: String, value: String)

  fun breadcrumb(message: String)

  fun state(key: String, value: String)
}
