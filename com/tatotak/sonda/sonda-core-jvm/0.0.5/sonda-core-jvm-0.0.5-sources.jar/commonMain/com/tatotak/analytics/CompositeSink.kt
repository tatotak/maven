package com.tatotak.analytics

class CompositeSink(private val sinks: List<AnalyticsSink>) : AnalyticsSink {
  constructor(vararg sinks: AnalyticsSink) : this(sinks.toList())

  override fun event(id: String, params: Map<String, Any>) = sinks.forEach { it.event(id, params) }

  override fun userProperty(id: String, value: String) = sinks.forEach {
    it.userProperty(id, value)
  }

  override fun breadcrumb(message: String) = sinks.forEach { it.breadcrumb(message) }

  override fun state(key: String, value: String) = sinks.forEach { it.state(key, value) }
}
