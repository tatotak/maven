package com.tatotak.analytics

fun interface ElapsedTime {
  fun now(): Long
}
