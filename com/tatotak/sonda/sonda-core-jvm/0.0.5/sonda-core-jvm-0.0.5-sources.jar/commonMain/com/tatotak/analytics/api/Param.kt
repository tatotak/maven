package com.tatotak.analytics.api

import com.tatotak.analytics.api.consts.AnalyticsParams
import com.tatotak.analytics.api.model.TraceStatus

/**
 * A single Firebase event parameter, key and value bound together.
 *
 * There is deliberately no free-form subclass: a new key means a new subclass here, which is what
 * stops `status` / `result` / `is_success` style drift from coming back. Keys come from
 * [com.tatotak.analytics.api.consts.AnalyticsParams] so the wire format matches what is already in
 * BigQuery.
 */
sealed class Param(val key: String, val value: Any) {

  // Envelope — added by Analytics, not by call sites.
  class Path(path: AnalyticsPath) : Param(AnalyticsParams.PATH, path.value)

  class FlowId(flowId: String) : Param(AnalyticsParams.FLOW_ID, flowId)

  // click
  class Target(target: String) : Param(AnalyticsParams.TARGET, target)

  class NextValue(nextValue: Any) : Param(AnalyticsParams.NEXT_VALUE, nextValue)

  // process
  class Status(traceStatus: TraceStatus) : Param(AnalyticsParams.STATUS, traceStatus.value)

  class Action(action: String) : Param(AnalyticsParams.ACTION, action)

  class Step(name: String) : Param(AnalyticsParams.STEP, name)

  class DurationMs(durationMs: Long) : Param(AnalyticsParams.DURATION_MS, durationMs)

  // Failure detail
  class FaultCode(faultCode: String) : Param(AnalyticsParams.FAULT_CODE, faultCode)

  class Reason(reason: String) : Param(AnalyticsParams.REASON, reason)

  // G4a
  class ScreenName(value: String) : Param(AnalyticsParams.G4A.SCREEN_NAME, value)

  class ScreenClass(value: String) : Param(AnalyticsParams.G4A.SCREEN_CLASS, value)

  class Method(value: String) : Param(AnalyticsParams.G4A.METHOD, value)

  class SearchTerm(value: String) : Param(AnalyticsParams.G4A.SEARCH_TERM, value)

  // testing
  class Test(value: String) : Param(AnalyticsParams.G4A.TEST, value)
}

internal fun Collection<Param>.wrap(): Map<String, Any> {
  return associate { it.key to it.value }
}
