package com.tatotak.analytics.api

import kotlin.random.Random

/** Use to generate flow id */
object FlowId {
  fun generate(random: Random = Random) = (random.nextLong() ushr 1).toString(36)
}
