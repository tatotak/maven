package com.tatotak.analytics

class ConsoleSink : AnalyticsSink {
  override fun event(id: String, bundle: Map<String, Any>) {
    val bundleContents = bundle.keys.joinToString(", ") { key -> "$key=${bundle[key]}" }
    println(">>event id=$id bundle={$bundleContents}")
    //    TODO("Not yet implemented")
  }

  override fun userProperty(id: String, value: String) {
    println(">>userProperty id=$id value=$value")
    //    TODO("Not yet implemented")
  }

  override fun breadcrumb(message: String) {
    println(">>breadcrumb message=$message")
    //    TODO("Not yet implemented")
  }

  override fun state(key: String, value: String) {
    println(">>breadcrumb key=$key value=$value")
    //    TODO("Not yet implemented")
  }
}
