package com.tatotak.analytics

import com.tatotak.analytics.api.AnalyticsPath
import com.tatotak.analytics.api.Param
import com.tatotak.analytics.api.UserProperty
import com.tatotak.analytics.api.consts.AnalyticsEventName
import com.tatotak.analytics.api.consts.AnalyticsEventName.G4A.LOGIN
import com.tatotak.analytics.api.consts.AnalyticsEventName.G4A.SEARCH
import com.tatotak.analytics.api.consts.AnalyticsEventName.HIT
import com.tatotak.analytics.api.consts.AnalyticsEventName.LOG
import com.tatotak.analytics.api.consts.AnalyticsEventName.TOGGLE
import com.tatotak.analytics.api.model.TraceStatus
import com.tatotak.analytics.api.wrap

/**
 * Logs the three unified events, tagged with the [path] and [flowId] it was built with.
 *
 * Instances are cheap and immutable — nest them with [scope] so a screen deeper in a flow reports
 * `receive/summary` without any call site passing a path around.
 */
class Analytics(
    val path: AnalyticsPath,
    val flowId: String?,
    internal val sink: AnalyticsSink,
    internal val elapsed: ElapsedTime,
) {

  class Factory(private val sink: AnalyticsSink, private val elapsed: ElapsedTime) {
    fun create(path: AnalyticsPath = AnalyticsPath.Root, flowId: String? = null): Analytics =
        Analytics(path = path, flowId = flowId, sink = sink, elapsed = elapsed)
  }

  /** The user activated a control that carries no value of its own. */
  fun hit(target: String, vararg params: Param) {
    emit(HIT, params.asList() + Param.Target(target))
  }

  /** The user activated a control that carries no value of its own. */
  fun toggle(target: String, newValue: Boolean, vararg params: Param) {
    emit(TOGGLE, params.asList() + Param.Target(target) + Param.NextValue(newValue))
  }

  /** [action] happened once. Reach for [trace] instead when the elapsed time matters. */
  fun log(action: String, vararg params: Param) {
    emit(LOG, params.asList() + Param.Action(action))
  }

  /** [target] visible. make sure it's not recomposing */
  fun seen(target: String? = null) {
    emit(AnalyticsEventName.SEEN, listOfNotNull(target?.let { Param.Target(it) }))
  }

  /** "Who is the user?, for segmenting in GA4. If it's related to what the state was use params */
  fun userProperty(property: UserProperty) {
    sink.userProperty(property.name, property.value)
  }

  /** A crumb for the next crash report, tagged with [path] so the trail reads as a route. */
  fun breadcrumb(message: String) {
    sink.breadcrumb(if (path.value.isEmpty()) message else "${path.value}:$message")
  }

  /** A key/value attached to every future crash report. Global, and last write wins. */
  fun state(key: String, value: String) {
    sink.state(key, value)
  }

  /**
   * Work worth timing. Emits TraceStatus.Started when called, so work that dies mid-way still
   * leaves a record that it began; the returned [Trace] emits the rest, each carrying time since
   * this call.
   */
  fun trace(action: String, vararg params: Param): Trace {
    val base = params.asList() + Param.Action(action)
    emit(LOG, base + Param.Status(TraceStatus.Started))
    return Trace(base)
  }

  /** Inlined, so [block] may suspend and may `return` out of the enclosing function. */
  inline fun <T> trace(action: String, vararg params: Param, block: Trace.() -> T): T =
      trace(action, *params).block()

  private fun emit(eventName: String, params: List<Param>) {
    val envelope = buildList {
      addAll(params)
      add(Param.Path(path))
      flowId?.let { add(Param.FlowId(it)) }
    }
    sink.event(eventName, envelope.wrap())
  }

  inner class Trace internal constructor(private val base: List<Param>) {
    private val startedAt = elapsed.now()

    /** One timed row carrying [params]. The four below are sugar over it. */
    fun record(vararg params: Param) = emit(params.asList())

    fun step(step: String, vararg params: Param) = emit(params.asList() + Param.Step(step))

    fun succeed(vararg params: Param) = emit(params.asList() + Param.Status(TraceStatus.Succeeded))

    fun fail(faultCode: String? = null, reason: String? = null, vararg params: Param) =
        emit(
            params.asList() +
                listOfNotNull(faultCode?.let(Param::FaultCode), reason?.let(Param::Reason)) +
                Param.Status(TraceStatus.Failed)
        )

    fun cancel(reason: String? = null, vararg params: Param) =
        emit(
            params.asList() +
                listOfNotNull(reason?.let(Param::Reason)) +
                Param.Status(TraceStatus.Cancelled)
        )

    private fun emit(params: List<Param>) =
        emit(LOG, base + params + Param.DurationMs(elapsed.now() - startedAt))
  }

  /** MAKE SURE it doesn't recompose */
  fun screen(extra: String? = null, screenClass: String? = null) {
    emit(
        AnalyticsEventName.G4A.SCREEN_VIEW,
        listOfNotNull(
            Param.ScreenName((extra?.let { path + it } ?: path).value),
            screenClass?.let(Param::ScreenClass),
        ),
    )
  }

  fun login(method: String, vararg params: Param) {
    emit(LOGIN, params.asList() + Param.Method(method))
  }

  fun search(term: String, vararg params: Param) {
    emit(SEARCH, params.asList() + Param.SearchTerm(term))
  }
}

fun Analytics.rebase(path: AnalyticsPath, flowId: String? = this.flowId): Analytics =
    Analytics(path, flowId, sink, elapsed)

/** Appends a path segment, keeping the same [flowId]. */
fun Analytics.scope(segment: String): Analytics = Analytics(path + segment, flowId, sink, elapsed)
