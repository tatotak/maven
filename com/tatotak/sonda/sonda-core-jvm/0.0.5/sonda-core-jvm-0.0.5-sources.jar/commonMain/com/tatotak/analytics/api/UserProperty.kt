package com.tatotak.analytics.api

/**
 * One Firebase user property — a new property means a new subclass here, as with [Param].
 *
 * Firebase stores every value as a string. Booleans are written as `true` / `false` so they read
 * the same as booleans in [Param], which go through `toString()`.
 */
sealed class UserProperty(val name: String, val value: String)
