package com.tatotak.analytics.api.consts

object AnalyticsParams {
  const val ACTION = "action"
  const val DURATION_MS = "duration_ms"
  const val FLOW_ID = "flow_id"
  const val PATH = "path"
  const val TARGET = "target"
  const val NEXT_VALUE = "next_value"
  const val STEP = "step"
  const val STATUS = "status"

  const val FAULT_CODE = "fault_code"
  const val REASON = "reason"

  // Google-defined keys, exact spelling required
  // https://support.google.com/analytics/answer/9234069?sjid=13426116773556874816-EU
  object G4A {
    const val SCREEN_NAME = "screen_name"
    const val SCREEN_CLASS = "screen_class"
    const val METHOD = "method"
    const val SEARCH_TERM = "search_term"
    const val TEST = "test"
  }
}
