package com.tatotak.analytics.api

/**
 * Where an event happened, as `receive/summary/confirm`.
 *
 * The path carries the feature and screen so event names never have to. Segments accumulate as
 * scopes nest, see `Analytics.scope`.
 */
data class AnalyticsPath(val value: String) {

  operator fun plus(segment: String): AnalyticsPath =
    when {
      segment.isEmpty() -> this
      value.isEmpty() -> of(segment)
      else -> of("$value/$segment")
    }

  override fun toString(): String = value

  companion object {
    /** Firebase drops anything past this, so clamp before it reaches the wire. */
    const val MAX_LENGTH = 100

    val Root = AnalyticsPath("")

    fun of(vararg segments: String): AnalyticsPath {
      val joined = segments.filter { it.isNotEmpty() }.joinToString(SEPARATOR)
      if (joined.length <= MAX_LENGTH) return AnalyticsPath(joined)

      //      Timber.e("Analytics path exceeds $MAX_LENGTH chars and was truncated: $joined")
      return AnalyticsPath(joined.take(MAX_LENGTH))
    }

    private const val SEPARATOR = "/"
  }
}
