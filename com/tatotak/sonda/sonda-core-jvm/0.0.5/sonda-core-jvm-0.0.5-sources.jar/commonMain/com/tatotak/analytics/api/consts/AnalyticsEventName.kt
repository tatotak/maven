package com.tatotak.analytics.api.consts

/**
 * The complete set of custom event names.
 *
 * `click` and `input` are things the user did, `process` is work the app did on their behalf.
 * Everything that used to be encoded in an event name now lives in [AnalyticsParams.PATH],
 * [AnalyticsParams.ACTION] and [AnalyticsParams.STATUS].
 */
object AnalyticsEventName {
  const val HIT = "hit"
  const val TOGGLE = "toggle"
  const val INPUT = "input"
  const val LOG = "log"
  const val SEEN = "seen"

  // G4A
  object G4A {
    const val SCREEN_VIEW = "screen_view"
    const val LOGIN = "login"
    const val SEARCH = "search"
  }
}
