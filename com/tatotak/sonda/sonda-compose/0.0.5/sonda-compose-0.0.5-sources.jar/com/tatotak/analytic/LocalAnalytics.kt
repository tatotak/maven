package com.tatotak.analytic

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.ProvidableCompositionLocal
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.staticCompositionLocalOf
import com.tatotak.analytics.Analytics
import com.tatotak.analytics.api.FlowId
import com.tatotak.analytics.rebase
import com.tatotak.analytics.scope

val LocalAnalytics: ProvidableCompositionLocal<Analytics> = staticCompositionLocalOf {
  error("No Analytics provided. Wrap the root, previews and tests in ProvideAnalytics.")
}

@Composable
fun ProvideAnalytics(analytics: Analytics, content: @Composable () -> Unit) {
  CompositionLocalProvider(LocalAnalytics provides analytics, content = content)
}

@Composable
fun AnalyticsScope(segment: String, content: @Composable Analytics.() -> Unit) {
  val parent = LocalAnalytics.current
  val scoped = remember(parent, segment) { parent.scope(segment) }
  ProvideAnalytics(scoped) { content(scoped) }
}

@Composable
fun AnalyticsFlow(
  segment: String,
  flowId: String = rememberSaveable { FlowId.generate() },
  content: @Composable Analytics.() -> Unit,
) {
  val parent = LocalAnalytics.current
  val scoped = remember(parent, segment, flowId) { parent.rebase(parent.path + segment, flowId) }
  ProvideAnalytics(scoped) { content(scoped) }
}

@Composable
fun Analytics.seenOnce(target: String? = null) {
  LaunchedEffect(target) { seen(target) }
}

@Composable
fun Analytics.screeenOnce(extra: String? = null, screenClass: String? = null) {
  LaunchedEffect(extra, screenClass) { screen(extra, screenClass) }
}

/**
 * One flow id for as long as this destination is on the back stack, rotation and death included.
 */
@Composable fun rememberFlowId(): String = rememberSaveable { FlowId.generate() }
