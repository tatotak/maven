package com.tatotak.analytics

import android.os.Bundle
import com.tatotak.analytics.api.Param

fun Collection<Param>.toBundle(): Bundle {
  val deduplicated = associateBy { it.key }
  return Bundle().apply { deduplicated.forEach { (key, param) -> put(key, param.value) } }
}

fun Bundle.put(key: String, value: Any) {
  when (value) {
    is String -> putString(key, value)
    is Int -> putLong(key, value.toLong())
    is Long -> putLong(key, value)
    is Float -> putDouble(key, value.toDouble())
    is Double -> putDouble(key, value)
    is Boolean -> putString(key, value.toString())
    is Collection<*>,
    is Array<
        *
    > -> {} // TODO Timber.e("Param '$key' is a collection) ignoring all collections, log individual
    else -> putString(key, value.toString())
  }
}
