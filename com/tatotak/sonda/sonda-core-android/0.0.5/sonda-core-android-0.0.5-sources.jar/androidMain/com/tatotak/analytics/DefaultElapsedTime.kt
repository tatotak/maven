package com.tatotak.analytics

import android.os.SystemClock

class DefaultElapsedTime : ElapsedTime {
  override fun now(): Long = SystemClock.elapsedRealtime()
}
