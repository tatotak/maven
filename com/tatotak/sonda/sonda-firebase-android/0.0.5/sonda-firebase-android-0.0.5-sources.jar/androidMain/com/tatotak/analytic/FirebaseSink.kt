package com.tatotak.analytic

import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.crashlytics.FirebaseCrashlytics
import com.tatotak.analytics.AnalyticsSink

/**
 * Writes each event twice — to GA4 for querying, to the crash report timeline for debugging. The
 * two writes are independent, so a degraded GA4 pipeline does not take breadcrumbs with it.
 */
class FirebaseSink(
    private val analytics: FirebaseAnalytics,
    private val crashlytics: FirebaseCrashlytics,
) : AnalyticsSink {
  override fun event(id: String, params: Map<String, Any>) {
    //    Timber.d("logEvent: ${id}, params: $bundle")
    analytics.logEvent(id, params.clamp().toBundle())
  }

  override fun userProperty(id: String, value: String) {
    //    Timber.d("set userProperty: ${property.name}, value: ${property.value}")
    analytics.setUserProperty(id, value)
  }

  override fun breadcrumb(message: String) {
    //    Timber.d("breadCrumb: $message")
    crashlytics.log(message)
  }

  override fun state(key: String, value: String) {
    //    Timber.d("setState: key=$key, value=$value")
    crashlytics.setCustomKey(key, value)
  }
}
