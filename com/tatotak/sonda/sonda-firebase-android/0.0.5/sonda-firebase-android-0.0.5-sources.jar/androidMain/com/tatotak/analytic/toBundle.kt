package com.tatotak.analytic

import android.os.Bundle
import com.tatotak.analytics.put

/**
 * Firebase accepts only [String], [Long], [Double] and [Bundle]. lists are dropped outright because
 * Firebase discards the whole parameter.
 *
 * See https://firebase.google.com/docs/analytics/errors
 */
fun Map<String, Any>.toBundle(): Bundle {
  return Bundle().apply { forEach { (key, param) -> put(key, param) } }
}

fun Map<String, Any>.clamp() =
    if (size > FirebaseConst.MAX_PARAMS) {
      // TODO    Timber.e("Event has ${deduplicated.size} params, Firebase keeps only
      // ${Param.MAX_PARAMS}")
      this
      // todo actually remove
    } else {
      this
    }
