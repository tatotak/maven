package com.tatotak.analytic

object FirebaseConst {
  /** Firebase truncates past this; we truncate first so it is visible in Logcat. */
  const val MAX_PARAM_VALUE_LENGTH = 100

  /** Firebase silently drops params past this. */
  const val MAX_PARAMS = 25

  const val MAX_USER_PROPERTY_NAME_LENGTH = 24

  const val MAX_USER_PROPERTY_VALUE_LENGTH = 36

  const val MAX_PROPERTIES = 25
}
