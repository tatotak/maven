package com.tatotak.loop.test

import com.tatotak.loop.Next
import com.tatotak.loop.Reducer

/**
 * Tiny test DSL for pure reducers.
 *
 * ```
 * UpdateSpec(::update)
 *     .given(State.initial())
 *     .whenEvent(Event.Clicked)
 *     .thenState(State.loading)
 *     .thenEffects(Effect.FetchData)
 * ```
 *
 * Supports chaining for multi-step state machine tests:
 * ```
 * val spec = UpdateSpec(::update)
 *
 * spec.given(State.initial())
 *     .whenEvent(Event.Clicked)
 *     .thenState(State.loading)
 *     .thenEffects(Effect.FetchData)
 *
 * spec.given(State.loading)
 *     .whenEvent(Event.DataLoaded(data))
 *     .thenState(State.ready(data))
 *     .thenNoEffects()
 * ```
 */
class ReducerSpec<State, Event, Effect>(private val update: Reducer<State, Event, Effect>) {
    fun given(state: State): Given<State, Event, Effect> = Given(update, state)

    class Given<State, Event, Effect>(
        private val update: Reducer<State, Event, Effect>,
        private val state: State,
    ) {
        fun whenEvent(event: Event): Then<State, Effect> = Then(update(state, event))
    }

    class Then<State, Effect>(val next: Next<State, Effect>) {
        fun thenState(expected: State): Then<State, Effect> = apply {
            check(next.state == expected) { "Expected state $expected but got ${next.state}" }
        }

        fun thenNoStateChange(): Then<State, Effect> = apply {
            check(next.state == null) { "Expected no state change but got ${next.state}" }
        }

        fun thenEffects(vararg expected: Effect): Then<State, Effect> = apply {
            val actual = next.effects.toList()
            check(actual == expected.toList()) { "Expected effects ${expected.toList()} but got $actual" }
        }

        fun thenNoEffects(): Then<State, Effect> = apply {
            check(next.effects.isEmpty()) { "Expected no effects but got ${next.effects}" }
        }
    }
}