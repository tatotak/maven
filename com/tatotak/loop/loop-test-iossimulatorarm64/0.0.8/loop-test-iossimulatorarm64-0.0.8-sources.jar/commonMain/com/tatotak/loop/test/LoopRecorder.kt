package com.tatotak.loop.test

import com.tatotak.loop.Next
import com.tatotak.loop.plugin.LoopPlugin
import kotlinx.atomicfu.locks.SynchronizedObject
import kotlinx.atomicfu.locks.synchronized

class LoopRecorder<State, Event, Effect> : LoopPlugin<State, Event, Effect> {
  private val lock = SynchronizedObject()

  private val _states = mutableListOf<State>()
  private val _effects = mutableListOf<Effect>()
  private val _events = mutableListOf<Pair<State, Event>>()
  private val _eventsFromEffects = mutableListOf<Event>()
  private val _droppedEvents = mutableListOf<Event>()
  private val _updates = mutableListOf<Triple<State, Event, Next<State, Effect>>>()
  private val _reduceErrors = mutableListOf<Triple<State, Event, Throwable>>()
  private val _effectErrors = mutableListOf<Throwable>()
  private val _eventSourceErrors = mutableListOf<Throwable>()
  private var _initState: State? = null
  private var _initEffects: Set<Effect>? = null

  val states: List<State>
    get() = synchronized(lock) { _states.toList() }

  val effects: List<Effect>
    get() = synchronized(lock) { _effects.toList() }

  val events: List<Pair<State, Event>>
    get() = synchronized(lock) { _events.toList() }

  val eventsFromEffects: List<Event>
    get() = synchronized(lock) { _eventsFromEffects.toList() }

  val droppedEvents: List<Event>
    get() = synchronized(lock) { _droppedEvents.toList() }

  val updates: List<Triple<State, Event, Next<State, Effect>>>
    get() = synchronized(lock) { _updates.toList() }

  val reduceErrors: List<Triple<State, Event, Throwable>>
    get() = synchronized(lock) { _reduceErrors.toList() }

  val effectErrors: List<Throwable>
    get() = synchronized(lock) { _effectErrors.toList() }

  val eventSourceErrors: List<Throwable>
    get() = synchronized(lock) { _eventSourceErrors.toList() }

  val initState: State?
    get() = synchronized(lock) { _initState }

  val initEffects: Set<Effect>?
    get() = synchronized(lock) { _initEffects }

  override fun onStart(initialState: State, initialEffects: Set<Effect>) =
      synchronized(lock) {
        _initState = initialState
        _initEffects = initialEffects
      }

  override fun onEvent(state: State, event: Event) =
      synchronized(lock) {
        _events.add(state to event)
        Unit
      }

  override fun onReduce(oldState: State, event: Event, next: Next<State, Effect>) =
      synchronized(lock) {
        _updates.add(Triple(oldState, event, next))
        next.state?.let { _states.add(it) }
        Unit
      }

  override fun onEffect(effect: Effect) =
      synchronized(lock) {
        _effects.add(effect)
        Unit
      }

  override fun onEventFromEffect(event: Event) =
      synchronized(lock) {
        _eventsFromEffects.add(event)
        Unit
      }

  override fun onEventDropped(event: Event) =
      synchronized(lock) {
        _droppedEvents.add(event)
        Unit
      }

  override fun onReduceException(state: State, event: Event, error: Throwable) =
      synchronized(lock) {
        _reduceErrors.add(Triple(state, event, error))
        Unit
      }

  override fun onEffectException(error: Throwable) =
      synchronized(lock) {
        _effectErrors.add(error)
        Unit
      }

  override fun onEventSourceException(error: Throwable) =
      synchronized(lock) {
        _eventSourceErrors.add(error)
        Unit
      }

  fun clear() =
      synchronized(lock) {
        _states.clear()
        _effects.clear()
        _events.clear()
        _eventsFromEffects.clear()
        _droppedEvents.clear()
        _updates.clear()
        _reduceErrors.clear()
        _effectErrors.clear()
        _eventSourceErrors.clear()
        _initState = null
        _initEffects = null
      }
}
