package com.tatotak.loop.test

import com.tatotak.loop.EffectHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.launch

/**
 * Drive an [com.tatotak.loop.EffectHandler] from a test with incremental input and live access to emitted events.
 * Use from `runTest { ... }` so virtual time and `advanceTimeBy` work for debounce/throttle/delay
 * testing and for verifying [com.tatotak.loop.ExecutionPolicy] policies.
 *
 * ```
 * runTest {
 *     val harness = EffectHandlerHarness(myHandler, this)
 *
 *     harness.send(Effect.Search("a"))
 *     advanceTimeBy(100)
 *     harness.send(Effect.Search("ab"))
 *     advanceTimeBy(500)
 *
 *     assertEquals(listOf(Event.Results("ab", ...)), harness.events)
 *     harness.close()
 * }
 * ```
 *
 * Input is an UNLIMITED [Channel] so effects sent before the handler's internal subscriber setup
 * completes (notably the subscriber-count gating in `subtypeEffectHandler`) are safely buffered
 * until the upstream is ready to consume.
 */
class EffectHandlerHarness<Effect, Event>(
  handler: EffectHandler<Effect, Event>,
  scope: CoroutineScope,
) {
  private val input = Channel<Effect>(Channel.UNLIMITED)
  private val received = mutableListOf<Event>()
  private val job: Job =
    scope.launch { handler(input.receiveAsFlow()).collect { received.add(it) } }

  /** Queue an effect for processing. Non-suspending; safe to call from any context. */
  fun send(effect: Effect) {
    input.trySend(effect)
  }

  /**
   * Snapshot of events emitted so far. Call after `advanceTimeBy` / `runCurrent` to make sure the
   * scheduler has drained pending continuations into the list.
   */
  val events: List<Event>
    get() = received.toList()

  /** Stop the handler. Call once per harness, typically at the end of the test. */
  fun close() {
    input.close()
    job.cancel()
  }
}

/**
 * One-shot fire-and-collect for the trivial case: a finite sequence of effects with no
 * time-sensitive operators. For debounce, throttle, or concurrency-policy testing, use
 * [EffectHandlerHarness] instead so you can advance virtual time between sends.
 */
suspend fun <Effect, Event> EffectHandler<Effect, Event>.process(
  vararg effects: Effect
): List<Event> = this(flowOf(*effects)).toList()
