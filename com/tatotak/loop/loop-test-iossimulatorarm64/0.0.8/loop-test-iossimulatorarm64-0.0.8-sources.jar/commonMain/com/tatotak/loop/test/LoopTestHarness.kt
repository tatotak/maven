package com.tatotak.loop.test

import com.tatotak.loop.CoroutineLoop
import com.tatotak.loop.EffectHandler
import com.tatotak.loop.First
import com.tatotak.loop.LoopErrorHandler
import com.tatotak.loop.Next
import com.tatotak.loop.Reducer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeout

/**
 * Full integration test harness for [com.tatotak.loop.CoroutineLoop]. Records state transitions,
 * effects, and events via [LoopRecorder] plugin.
 *
 * ```
 * @Test
 * fun `click triggers load effect`() = runTest {
 *     val harness = loopTestHarness(
 *         first = First.first(State.initial()),
 *         reducer = ::update,
 *         scope = this,
 *     )
 *
 *     harness.dispatch(Event.Clicked)
 *     runCurrent()
 *
 *     assertEquals(State.loading, harness.state)
 *     assertEquals(listOf(Effect.LoadData), harness.effects)
 * }
 * ```
 */
class LoopTestHarness<State, Event, Effect>(
  val loop: CoroutineLoop<State, Event, Effect>,
  val recorder: LoopRecorder<State, Event, Effect>,
) {
  /** Current state. */
  val state: State
    get() = loop.state.value

  /** All states that resulted from state changes, in order. */
  val states: List<State>
    get() = recorder.states

  /** All effects emitted by the reducer, in order. */
  val effects: List<Effect>
    get() = recorder.effects

  /** All events received by the reducer, paired with the state at that time. */
  val events: List<Pair<State, Event>>
    get() = recorder.events

  /** All events fed back from the effect handler, in order. */
  val eventsFromEffects: List<Event>
    get() = recorder.eventsFromEffects

  /** All events that were dropped (channel closed or full), in order. */
  val droppedEvents: List<Event>
    get() = recorder.droppedEvents

  /** All reducer invocations: (oldState, event, resultingNext). */
  val updates: List<Triple<State, Event, Next<State, Effect>>>
    get() = recorder.updates

  /** All exceptions thrown by the reducer. */
  val reduceErrors: List<Triple<State, Event, Throwable>>
    get() = recorder.reduceErrors

  /** All exceptions thrown by the effect handler. */
  val effectErrors: List<Throwable>
    get() = recorder.effectErrors

  /** All exceptions thrown by event sources. */
  val eventSourceErrors: List<Throwable>
    get() = recorder.eventSourceErrors

  fun dispatch(event: Event) = loop.dispatchEvent(event)

  /** Wait for state to match [predicate], with a timeout. */
  suspend fun awaitState(timeoutMs: Long = 1000, predicate: (State) -> Boolean): State =
    withTimeout(timeoutMs) { loop.state.first { predicate(it) } }

  fun cancel() = loop.job.cancel()
}

/** Creates a [LoopTestHarness] with [LoopRecorder] wired in as a plugin. */
fun <State, Event, Effect> loopTestHarness(
  first: First<State, Effect>,
  reducer: Reducer<State, Event, Effect>,
  scope: CoroutineScope,
  effectHandler: EffectHandler<Effect, Event>? = null,
  errorHandler: LoopErrorHandler = LoopErrorHandler.rethrow(),
): LoopTestHarness<State, Event, Effect> {
  val recorder = LoopRecorder<State, Event, Effect>()
  val loop =
    CoroutineLoop.Factory(
        reducer = reducer,
        effectHandler = effectHandler,
        plugins = listOf(recorder),
        errorHandler = errorHandler,
      )
      .create(scope, first)
  return LoopTestHarness(loop, recorder)
}
