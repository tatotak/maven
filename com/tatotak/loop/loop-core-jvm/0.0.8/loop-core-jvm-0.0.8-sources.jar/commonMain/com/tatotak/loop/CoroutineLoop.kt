package com.tatotak.loop

import com.tatotak.loop.plugin.LoopPlugin
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers.Default
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.consumeAsFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Single-use UDF state machine bound to a [CoroutineScope].
 *
 * Guarantees:
 * - Reducers execute strictly sequentially on [reducerDispatcher].
 * - Event and effect channels default to [Channel.UNLIMITED] so [dispatchEvent] never blocks.
 * - Cancelling [job] or the host [CoroutineScope] permanently tears down the loop.
 */
class CoroutineLoop<State, Event, Effect>
private constructor(
  scope: CoroutineScope,
  first: First<State, Effect>,
  private val reducer: Reducer<State, Event, Effect>,
  private val effectHandler: EffectHandler<Effect, Event>?,
  private val eventSources: List<Flow<Event>>,
  private val plugins: List<LoopPlugin<State, Event, Effect>>,
  private val errorHandler: LoopErrorHandler,
  private val reducerDispatcher: CoroutineDispatcher,
  eventChannelCapacity: Int = Channel.UNLIMITED,
  eventChannelOverflow: BufferOverflow = BufferOverflow.SUSPEND,
  effectChannelCapacity: Int = Channel.UNLIMITED,
  effectChannelOverflow: BufferOverflow = BufferOverflow.SUSPEND,
) : Loop<State, Event, Effect> {

  /**
   * Configuration and builder for creating [CoroutineLoop] instances.
   *
   * @param reducer Pure state transition function `(State, Event) -> Next<State, Effect>`.
   * @param effectHandler Asynchronous effect processor converting effects back into events.
   * @param eventSources External event streams (sensors, timers, push) collected into the loop.
   * @param plugins Lifecycle listeners for logging, metrics, or test assertions.
   * @param errorHandler Failure recovery strategy; defaults to crashing on unhandled errors.
   * @param reducerDispatcher Dispatcher executing the reducer; defaults to single-threaded
   *   sequential execution.
   * @param eventChannelCapacity Capacity for the event queue (default [Channel.UNLIMITED]).
   * @param eventChannelOverflow Overflow strategy if event queue fills (default
   *   [BufferOverflow.SUSPEND]).
   * @param effectChannelCapacity Capacity for the effect queue (default [Channel.UNLIMITED]).
   * @param effectChannelOverflow Overflow strategy if effect queue fills (default
   *   [BufferOverflow.SUSPEND]).
   */
  class Factory<State, Event, Effect>(
    private val reducer: Reducer<State, Event, Effect>,
    private val effectHandler: EffectHandler<Effect, Event>? = null,
    private val eventSources: List<Flow<Event>> = emptyList(),
    private val plugins: List<LoopPlugin<State, Event, Effect>> = emptyList(),
    private val errorHandler: LoopErrorHandler = LoopErrorHandler.rethrow(),
    private val reducerDispatcher: CoroutineDispatcher = Default.limitedParallelism(1),
    private val eventChannelCapacity: Int = Channel.UNLIMITED,
    private val eventChannelOverflow: BufferOverflow = BufferOverflow.SUSPEND,
    private val effectChannelCapacity: Int = Channel.UNLIMITED,
    private val effectChannelOverflow: BufferOverflow = BufferOverflow.SUSPEND,
  ) {
    fun create(
      scope: CoroutineScope,
      first: First<State, Effect>,
    ): CoroutineLoop<State, Event, Effect> {
      require(!(first.effects.isNotEmpty() && effectHandler == null)) {
        "Init produced effects but no effectHandler was provided"
      }
      return CoroutineLoop(
        scope = scope,
        first = first,
        reducer = reducer,
        effectHandler = effectHandler,
        eventSources = eventSources,
        plugins = plugins,
        errorHandler = errorHandler,
        reducerDispatcher = reducerDispatcher,
        eventChannelCapacity = eventChannelCapacity,
        eventChannelOverflow = eventChannelOverflow,
        effectChannelCapacity = effectChannelCapacity,
        effectChannelOverflow = effectChannelOverflow,
      )
    }
  }

  private val eventChannel = Channel<Event>(eventChannelCapacity, eventChannelOverflow)
  private val effectChannel = Channel<Effect>(effectChannelCapacity, effectChannelOverflow)

  private val _state = MutableStateFlow(first.state)

  override val state: StateFlow<State> = _state.asStateFlow()

  val job: Job

  init {
    plugins.forEach { it.onStart(_state.value, first.effects) }
    val job =
      scope.launch {
        launch {
          first.effects.forEach { effect ->
            plugins.forEach { it.onEffect(effect) }
            effectChannel.send(effect)
          }
        }

        launch(reducerDispatcher) {
          eventChannel.consumeAsFlow().collect { event ->
            val current = _state.value
            plugins.forEach { it.onEvent(current, event) }

            val next =
              try {
                reducer(current, event)
              } catch (c: CancellationException) {
                throw c
              } catch (t: Throwable) {
                plugins.forEach { it.onReduceException(current, event, t) }
                errorHandler.onReducerError(t)
                Next.noChange()
              }

            plugins.forEach { it.onReduce(current, event, next) }
            next.state?.let { _state.value = it }
            next.effects.forEach { effect ->
              plugins.forEach { it.onEffect(effect) }
              effectChannel.send(effect)
            }
          }
        }
        effectHandler?.let { handler ->
          launch {
            // Resubscribe on error so remaining effects are not stranded.
            while (isActive) {
              try {
                handler(effectChannel.receiveAsFlow()).collect { event ->
                  plugins.forEach { it.onEventFromEffect(event) }
                  dispatchEvent(event)
                }
                break
              } catch (c: CancellationException) {
                throw c
              } catch (u: UnhandledEffectException) {
                throw u
              } catch (t: Throwable) {
                plugins.forEach { it.onEffectException(t) }
                errorHandler.onEffectHandlerError(t)
                delay(errorHandler.effectHandlerRetryDelayMillis)
              }
            }
          }
        }
        eventSources.forEach { source ->
          launch {
            while (isActive) {
              try {
                source.collect { event -> dispatchEvent(event) }
                break
              } catch (c: CancellationException) {
                throw c
              } catch (t: Throwable) {
                plugins.forEach { it.onEventSourceException(t) }
                errorHandler.onEventSourceError(t)
                delay(errorHandler.eventSourceRetryDelayMillis)
              }
            }
          }
        }
      }
    job.invokeOnCompletion {
      eventChannel.close()
      effectChannel.close()
    }
    this.job = job
  }

  override fun dispatchEvent(event: Event) {
    val result = eventChannel.trySend(event)
    if (result.isFailure) {
      plugins.forEach { it.onEventDropped(event) }
    }
  }
}
