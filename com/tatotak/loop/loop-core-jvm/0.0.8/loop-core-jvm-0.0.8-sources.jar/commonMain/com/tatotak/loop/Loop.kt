package com.tatotak.loop

import kotlinx.coroutines.flow.StateFlow

interface Loop<State, Event, Effect> {
  val state: StateFlow<State>

  fun dispatchEvent(event: Event)

  companion object {
    fun <State, Effect, Event> reducer(): Reducer<State, Effect, Event> = { state, event ->
      Next.noChange()
    }

    inline fun <reified Effect : Any, Event> effectHandler(): EffectHandler<Effect, Event> =
        subtypeEffectHandler {}
  }
}
