package com.tatotak.loop

typealias Reducer<State, Event, Effect> = (state: State, event: Event) -> Next<State, Effect>
