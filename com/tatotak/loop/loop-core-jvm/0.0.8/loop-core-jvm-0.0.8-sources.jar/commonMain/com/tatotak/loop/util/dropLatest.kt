@file:OptIn(ExperimentalAtomicApi::class)

package com.tatotak.loop.util

import kotlin.concurrent.atomics.AtomicBoolean
import kotlin.concurrent.atomics.ExperimentalAtomicApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.FlowCollector
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.launch

@PublishedApi
internal fun <In, Out> Flow<In>.dropLatest(
  block: suspend (FlowCollector<Out>, In) -> Unit
): Flow<Out> = channelFlow {
  val inFlight = AtomicBoolean(false)
  collect { value ->
    if (!inFlight.compareAndSet(expectedValue = false, newValue = true)) return@collect
    launch {
      try {
        block(FlowCollector { value -> send(value) }, value)
      } finally {
        inFlight.store(false)
      }
    }
  }
}
