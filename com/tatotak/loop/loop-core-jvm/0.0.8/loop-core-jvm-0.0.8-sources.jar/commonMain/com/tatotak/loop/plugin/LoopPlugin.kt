package com.tatotak.loop.plugin

import com.tatotak.loop.Next


/** Lifecycle hooks for loop execution. */
// todo metrics, timing, analytics, record/time travel, persistence, saved state (done), crash
//  reporting
interface LoopPlugin<State, Event, Effect> {
  fun onStart(initialState: State, initialEffects: Set<Effect>) {}

  fun onEvent(state: State, event: Event) {}

  fun onReduce(oldState: State, event: Event, next: Next<State, Effect>) {}

  fun onEffect(effect: Effect) {}

  fun onEventFromEffect(event: Event) {}

  fun onEventDropped(event: Event) {}

  fun onReduceException(state: State, event: Event, error: Throwable) {}

  fun onEffectException(error: Throwable) {}

  fun onEventSourceException(error: Throwable) {}
}
