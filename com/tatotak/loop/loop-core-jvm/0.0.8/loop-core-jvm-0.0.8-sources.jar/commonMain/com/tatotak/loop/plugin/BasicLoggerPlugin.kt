package com.tatotak.loop.plugin

import com.tatotak.loop.Next

/** Standard Logcat output for development. */
class BasicLoggerPlugin<State, Event, Effect>(private val tag: String = "MVI_Loop") :
  LoopPlugin<State, Event, Effect> {

  override fun onStart(initialState: State, initialEffects: Set<Effect>) {
    println("$tag: Start: state=$initialState effects=$initialEffects")
  }

  override fun onEvent(state: State, event: Event) {
    println("$tag: Event: $event (Current State: $state)")
  }

  override fun onReduce(oldState: State, event: Event, next: Next<State, Effect>) {
    if (next.state != null) {
      println("$tag: State Changed -> ${next.state}")
    }
    if (next.effects.isNotEmpty()) {
      println("$tag: Effects Dispatched -> ${next.effects}")
    }
  }

  override fun onEventDropped(event: Event) {
    println("$tag:Event Dropped (Queue Full or Loop Dead): $event")
  }

  override fun onReduceException(state: State, event: Event, error: Throwable) {
    println("$tag: CRASH in Reducer! Event: $event, $error")
  }
}

