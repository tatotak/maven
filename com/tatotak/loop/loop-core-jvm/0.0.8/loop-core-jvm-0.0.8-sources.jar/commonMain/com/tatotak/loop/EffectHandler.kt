package com.tatotak.loop

import com.tatotak.loop.util.dropLatest
import kotlin.reflect.KClass
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.FlowCollector
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.flow.filterIsInstance
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.shareIn
import kotlinx.coroutines.flow.transform
import kotlinx.coroutines.flow.transformLatest
import kotlinx.coroutines.launch

/** Converts flow of Effects into flow of Events */
typealias EffectHandler<Effect, Event> = suspend (Flow<Effect>) -> Flow<Event>

/**
 * Concurrency strategy for handling overlapping effects.
 * - [All]: Process all effects concurrently.
 * - [Latest]: Cancel in-flight handler on new arrival (e.g. search).
 * - [DropLatest]: Drop new effects while in-flight (e.g. refresh).
 */
sealed interface ExecutionPolicy {
  data object All : ExecutionPolicy

  data object Latest : ExecutionPolicy

  data object DropLatest : ExecutionPolicy
}

/**
 * Routes upstream effects to registered sub-handlers by type. Throws [UnhandledEffectException] if
 * an effect matches no registration.
 */
inline fun <reified Effect : Any, Event> subtypeEffectHandler(
  crossinline builder: SubtypeEffectHandlerBuilder<Effect, Event>.() -> Unit
): EffectHandler<Effect, Event> = { upstream ->
  channelFlow {
    val handlerBuilder = SubtypeEffectHandlerBuilder<Effect, Event>().apply(builder)

    handlerBuilder.sources.forEach { source -> launch { source.collect { send(it) } } }

    val registrations = handlerBuilder.registrations
    val channels = registrations.map { Channel<Effect>(Channel.UNLIMITED) }

    registrations.forEachIndexed { index, registration ->
      launch {
        try {
          registration.transformer(channels[index].receiveAsFlow()).collect { send(it) }
        } finally {
          channels[index].close()
        }
      }
    }

    launch {
      try {
        upstream.collect { effect ->
          var routed = false
          registrations.forEachIndexed { index, registration ->
            if (registration.type.isInstance(effect)) {
              channels[index].trySend(effect)
              routed = true
            }
          }
          if (!routed) throw UnhandledEffectException(effect)
        }
      } finally {
        channels.forEach { it.close() }
      }
    }
  }
}

class SubtypeEffectHandlerBuilder<Effect : Any, Event> {

  @PublishedApi
  internal class Registration<Effect : Any, Event>(
    val type: KClass<out Effect>,
    val transformer: (Flow<Effect>) -> Flow<Event>,
  )

  @PublishedApi internal val registrations = mutableListOf<Registration<Effect, Event>>()

  val sources = mutableListOf<Flow<Event>>()

  /** Transforms the stream of [T] effects using Flow operators. */
  inline fun <reified T : Effect> addTransformer(
    crossinline transform: (source: Flow<T>) -> Flow<Event>
  ) {
    registrations.add(
      Registration(T::class) { upstream -> transform(upstream.filterIsInstance<T>()) }
    )
  }

  /** Maps each [T] effect to a single [Event] (e.g. API query). */
  inline fun <reified T : Effect> addFunction(
    dispatcher: CoroutineDispatcher? = null,
    executionPolicy: ExecutionPolicy = ExecutionPolicy.All,
    crossinline function: suspend (T) -> Event,
  ) {
    addTransformer<T> { flow ->
      flow
        .applyExecutionPolicy(executionPolicy) { effect -> emit(function(effect)) }
        .applyDispatcher(dispatcher)
    }
  }

  /** Executes a fire-and-forget action for each [T] effect. */
  inline fun <reified T : Effect> addAction(
    dispatcher: CoroutineDispatcher? = null,
    executionPolicy: ExecutionPolicy = ExecutionPolicy.All,
    crossinline consumer: suspend (T) -> Unit,
  ) {
    addTransformer<T> { flow ->
      flow
        .applyExecutionPolicy<T, Event>(executionPolicy) { effect -> consumer(effect) }
        .applyDispatcher(dispatcher)
    }
  }

  /** Emits zero or more [Event]s for each [T] effect. */
  inline fun <reified T : Effect> addValueCollector(
    dispatcher: CoroutineDispatcher? = null,
    executionPolicy: ExecutionPolicy = ExecutionPolicy.All,
    crossinline collector: suspend FlowCollector<Event>.(T) -> Unit,
  ) {
    addTransformer<T> { flow ->
      flow
        .applyExecutionPolicy(executionPolicy) { effect -> collector(effect) }
        .applyDispatcher(dispatcher)
    }
  }

  @PublishedApi
  internal fun <Out> Flow<Out>.applyDispatcher(dispatcher: CoroutineDispatcher?): Flow<Out> =
    if (dispatcher != null) flowOn(dispatcher) else this

  @PublishedApi
  internal inline fun <In, Out> Flow<In>.applyExecutionPolicy(
    executionPolicy: ExecutionPolicy,
    crossinline block: suspend FlowCollector<Out>.(In) -> Unit,
  ): Flow<Out> =
    when (executionPolicy) {
      ExecutionPolicy.All -> transform { block(it) }
      ExecutionPolicy.Latest -> transformLatest { block(it) }
      ExecutionPolicy.DropLatest -> dropLatest { collector, value -> collector.block(value) }
    }
}

/**
 * Merges multiple effect handlers into one, forwarding all effects to each handler concurrently.
 */
fun <Effect, Event> compositeEffectHandler(
  vararg handlers: EffectHandler<Effect, Event>
): EffectHandler<Effect, Event> = { upstream ->
  channelFlow {
    val shared = upstream.shareIn(this, SharingStarted.Eagerly, replay = 0)
    handlers.forEach { handler -> launch { handler(shared).collect { send(it) } } }
  }
}

class UnhandledEffectException(effect: Any) :
  IllegalStateException(
    "Fatal: No handler defined for effect: $effect ${effect::class.qualifiedName}"
  )
