package com.tatotak.loop

data class Next<State, Effect> private constructor(val state: State?, val effects: Set<Effect>) {
  companion object {
    fun <State, Effect> next(state: State, vararg effects: Effect): Next<State, Effect> =
      Next(state, linkedSetOf(*effects))

    fun <State, Effect> next(state: State, effects: Set<Effect>): Next<State, Effect> =
      Next(state, effects)

    fun <State, Effect> dispatch(vararg effects: Effect): Next<State, Effect> =
      Next(null, linkedSetOf(*effects))

    fun <State, Effect> dispatch(effects: Set<Effect>): Next<State, Effect> = Next(null, effects)

    fun <State, Effect> noChange(): Next<State, Effect> = Next(null, emptySet())
  }
}

data class First<State, Effect> private constructor(val state: State, val effects: Set<Effect>) {
  companion object {
    fun <State, Effect> first(state: State, vararg effects: Effect): First<State, Effect> =
      First(state, linkedSetOf(*effects))

    fun <State, Effect> first(state: State, effects: Set<Effect>): First<State, Effect> =
      First(state, effects)
  }
}
