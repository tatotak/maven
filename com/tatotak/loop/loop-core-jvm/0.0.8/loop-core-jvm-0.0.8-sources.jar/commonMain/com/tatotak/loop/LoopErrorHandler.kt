package com.tatotak.loop

/**
 * Handles loop errors. Rethrowing terminates the loop; returning normally ignores reducer errors
 * via `noChange()` or retries handlers/sources after delay.
 */
interface LoopErrorHandler {
  fun onReducerError(error: Throwable) {
    throw error
  }

  fun onEffectHandlerError(error: Throwable) {
    throw error
  }

  fun onEventSourceError(error: Throwable) {
    throw error
  }

  val effectHandlerRetryDelayMillis: Long
    get() = 1000L

  val eventSourceRetryDelayMillis: Long
    get() = 1000L

  companion object {
    /** Crashes the loop on any unhandled exception. */
    fun rethrow(): LoopErrorHandler = object : LoopErrorHandler {}

    /** Swallows errors: reducers continue via `noChange()`, workers retry after delay. */
    fun swallow(): LoopErrorHandler =
      object : LoopErrorHandler {
        override fun onReducerError(error: Throwable) = Unit

        override fun onEffectHandlerError(error: Throwable) = Unit

        override fun onEventSourceError(error: Throwable) = Unit
      }
  }
}
